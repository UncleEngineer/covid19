from covid19uncle.covid19 import GlobalCovid19
from covid19uncle.covid19 import ThaiCovid19